package PI.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

public class EmpresaDao {

    Connection conectar;

    private void conectar() throws ClassNotFoundException, SQLException {
        // conectar ao banco de dados
        Class.forName("com.mysql.cj.jdbc.Driver");
        conectar = DriverManager.getConnection("jdbc:mysql://localhost:3306/empresa", "root", "");
    }

    public void salvarUsuario(String u, String s, String c) throws ClassNotFoundException, SQLException {
        conectar();
        //Enviar os dados para a tabela do BD
        PreparedStatement st = conectar.prepareStatement("INSERT INTO usuarios VALUES(?,?,?)");
        st.setString(1, u);
        st.setString(2, s);
        st.setString(3, c);
        st.executeUpdate(); //executa o comando INSERT
    }

    public int excluirUsuario(String u) throws ClassNotFoundException, SQLException {
        conectar();
        // Ecluir o usuário
        PreparedStatement st = conectar.prepareStatement("DELETE FROM usuarios WHERE usuario= ?");
        st.setString(1, u);
        int retorno = st.executeUpdate(); // executar o DELETE
        return retorno;
    }

    public ResultSet listarUsuarios() throws ClassNotFoundException, SQLException {
        conectar();
        // Buscar todos os dados que eu quero exibir na tabela
        PreparedStatement st = conectar.prepareStatement("SELECT * FROM usuarios");
        ResultSet usuarios = st.executeQuery(); // executa o SELECT acima
        return usuarios;
    }

    public ResultSet listarUsuariosPorCargo(String c) throws ClassNotFoundException, SQLException {
        conectar();
        // Buscar todos os dados que eu quero exibir na tabela
        PreparedStatement st = conectar.prepareStatement("SELECT * FROM usuarios WHERE cargo = ?");
        st.setString(1, c);
        ResultSet usuarios = st.executeQuery(); // executa o SELECT acima
        return usuarios;
    }

    public ResultSet buscarUsuario(String u) throws ClassNotFoundException, SQLException {
        conectar();
        // Buscar todos os dados que eu quero exibir na tabela
        PreparedStatement st = conectar.prepareStatement("SELECT * FROM usuarios WHERE usuario LIKE ?");
        st.setString(1, "%" + u + "%");
        ResultSet usuarios = st.executeQuery(); // executa o SELECT acima
        return usuarios;
    }
    public ResultSet logar(String u, String s) throws ClassNotFoundException, SQLException {
        conectar();
         // 3- Buscar esse usuário na tabela usuario do BD
            PreparedStatement st = conectar.prepareStatement("SELECT * FROM usuarios WHERE usuario=? AND senha=?");
            st.setString(1, u); // 1 para a primeira "?"
            st.setString(2, s); // 2 para a segunda "?"
            ResultSet usuario = st.executeQuery();
            return usuario;
    }
    public void alterarUsuario (String u, String s, String c) throws ClassNotFoundException, SQLException {
        conectar();
        // pegar os dados alterados e devolver para a tabela
            PreparedStatement st = conectar.prepareStatement("UPDATE usuarios SET senha= ?, cargo= ? WHERE usuario= ?");
            st.setString(1, s);
            st.setString(2, c);
            st.setString(3, u);
            st.executeUpdate(); //executa a alteração (UPDATE)
        
    }
}
