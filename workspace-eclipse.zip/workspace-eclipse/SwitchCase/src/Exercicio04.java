import java.util.Scanner;

public class Exercicio04 {

	public static void main(String[] args) {
		int codProd, codPais;
		double preco, imposto, vlrImposto, vTotal, vProduto, peso, vFinal;
		Scanner leia = new Scanner(System.in);
		System.out.println("Informe o código do produto");
		codProd = leia.nextInt();
		System.out.println("Informe o peso do produto (Kg)");
		peso = leia.nextDouble();
		System.out.println("Informe o código do país");
		codPais = leia.nextInt();
		peso = convGrama(peso);
		imposto = getImposto(codPais);
		preco = getPreco(codProd);
		vTotal = peso * preco;
		vlrImposto = vTotal * imposto;
		vFinal = vlrImposto + vTotal;
	}

	public static double calcTotal(int codProd, double pesoKg) {
		double preco, precoTotal;
		int pesoGr;
		pesoGr = convGrama(pesoKg);
		preco = getPreco(codProd);
		precoTotal = pesoGr * preco;
		return precoTotal;
	}

	/**
	 * Retorna o imposto de acordo com o código do país
	 * 
	 * @param codPais - Código do país
	 * @return valor do imposto ou -1 caso código inválido
	 */
	public static double getImposto(int codPais) {
		double imposto;
		switch (codPais) {
		case 1:
			imposto = 0;
			break;

		case 2:
			imposto = 0.15;
			break;
		case 3:
			imposto = 0.25;
			break;
		default:
			imposto = -1;
		}
		return imposto;

	}

	public static int convGrama(double kg) {
		return (int) kg * 1000;
	}

	public static double getPreco(int codProd) {
		double preco;
		switch (codProd) {
		case 1:
		case 2:
		case 3:
		case 4:
			preco = 10;
			break;
		case 5:
		case 6:
		case 7:
			preco = 25;
			break;
		case 8:
		case 9:
		case 10:
			preco = 30;
			break;
		default:
			preco = -1;
		}
		return preco;
	}
}
