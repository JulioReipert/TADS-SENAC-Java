import java.util.Scanner;

public class Exercicio11Lista2 {

	/*
	 * Crie um algoritmo que leia 3 números e informe qual o menor.
	 */
	public static void main(String[] args) {
		// variáveis
		int n1, n2, n3, opcao;
		Scanner ler = new Scanner(System.in);
		// exibir o menu
		System.out.println("**** Menu de Opções *****");
		System.out.println("1. Somar dois números");
		System.out.println("2. Raiz quadrada de um número ");
		System.out.println("3. Elevar um número a uma potência");
		System.out.println("**** Digite a opção desejada ****");
		opcao = ler.nextInt();
		switch (opcao) {
		case 1:
			System.out.println("Informe o primeiro número");
			n1 = ler.nextInt();
			System.out.println("Informe o segundo número");
			n2 = ler.nextInt();
			n3 = n1 + n2;
			System.out.println("A soma dos números é  " + n3);
			break;
		case 2:
			System.out.println("Informe o número");
			n1 = ler.nextInt();
			System.out.println("A raiz quadrada é " + Math.sqrt(n1));
			break;
		case 3:
			System.out.println("Informe a base");
			n1 = ler.nextInt();
			System.out.println("Informe o expoente");
			n2 = ler.nextInt();
			System.out.println("A potência é " + Math.pow(n1, n2));
			break;
		default:
			System.out.println("Opção inválida");
			break;
		}
	}
}
