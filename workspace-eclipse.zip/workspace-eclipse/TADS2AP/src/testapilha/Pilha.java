package testapilha;

public class Pilha {

    private int tamMax;
    private Object[] elementos;
    private int topo;
    private int tam;

    public Pilha(int tamMax) {
        this.tamMax = tamMax;
        this.elementos = new Object[tamMax];
        this.topo = -1;
        this.tam = 0;

    }

    public boolean estaVazia() {
        return tam == 0;
    }

    public boolean estaCheia() {
        return tam == tamMax;
    }

    public void empilhar(Object valor) {
        if (estaCheia()) {
            System.out.println("ERRO: a pilha esta cheia.");
        } else {
            tam++;
            topo++;
            elementos[topo] = valor;
        }
    }

    public Object desempilhar() {
        if (estaVazia()) {
            System.out.println("ERRO: a pilha esta vazia.");
            return -1;
        } else {
            tam--;
            topo--;
            return elementos[topo + 1];
        }
    }

    public Object espiarTopo() {
        if (estaVazia()) {
            System.out.println("ERRO: a pilha esta vazia");
            return -1;
        } else {
            return elementos[topo];
        }
    }

    public int tamanho() {
        return tam;
    }

    public void imprimirPilha() {
        for (int i = 0; i < tam; i++) {
            System.out.printf(elementos[i] + " ");
        }
    }
}
