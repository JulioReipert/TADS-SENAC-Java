package testapilha;

public class TestaPilha {

    public static void main(String[] args) {
        Pilha p = new Pilha(5);

        System.out.println(p.estaCheia());
        System.out.println(p.estaVazia());
        System.out.println(p.espiarTopo());
        p.empilhar(1);
        p.empilhar(2);
        p.empilhar(3);
        System.out.println(p.espiarTopo());
        p.empilhar(4);
        p.empilhar(5);
        System.out.println(p.estaCheia());
        System.out.println(p.estaVazia());
        System.out.println(p.espiarTopo());

        p.empilhar(6);

        p.imprimirPilha();

        System.out.println(p.desempilhar());
        System.out.println(p.desempilhar());
        System.out.println(p.desempilhar());
        System.out.println(p.desempilhar());
        System.out.println(p.desempilhar());
        p.desempilhar();
        p.desempilhar();
        p.desempilhar();
        p.desempilhar();
        p.desempilhar();
        p.desempilhar();
    }
}
