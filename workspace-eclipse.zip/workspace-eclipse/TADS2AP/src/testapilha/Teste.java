package testapilha;

import java.util.Arrays;

public class Teste {

    public static void main(String[] args) {
        String[] a = "etset".split("");
        System.out.println(Arrays.toString(a));

        Pilha p = new Pilha(a.length);

        for (int i = 0; i < a.length; i++) {
            p.empilhar(a[i]);
        }
        String saida = "";
        for (int i = 0; i < a.length; i++) {
            saida += p.desempilhar();
        }
    }
}
