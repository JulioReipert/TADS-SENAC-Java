package testapilha;

public class Carta {

}
