package testaFila;

public class TesteFilaDomino {

    public static void main(String[] args) {
        FilaDomino f = new FilaDomino(5);

        f.enfileirar(new PecaDomino(2, 5));
        f.enfileirar(new PecaDomino(3, 1));
        f.enfileirar(new PecaDomino(0, 4));
        f.enfileirar(new PecaDomino(3, 3));
        f.enfileirar(new PecaDomino(1, 6));
        f.enfileirar(new PecaDomino(6, 6));

        f.imprimirFila();

        System.out.println(f.desenfileirar());
        System.out.println(f.desenfileirar());
        System.out.println(f.desenfileirar());
        System.out.println(f.desenfileirar());
        System.out.println(f.desenfileirar());
        System.out.println(f.desenfileirar());

        f.imprimirFila();
    }
}
