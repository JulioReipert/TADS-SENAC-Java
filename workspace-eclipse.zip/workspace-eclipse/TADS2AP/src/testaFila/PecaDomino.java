package testaFila;

public class PecaDomino {

    private int ladoEsquerdo, ladoDireito;

    public PecaDomino(int ladoEsquerdo, int ladoDireito) {
        this.ladoEsquerdo = ladoEsquerdo;
        this.ladoDireito = ladoDireito;

    }

    @Override
    public String toString() {
        return "[" + ladoEsquerdo + "|" + ladoDireito + "]";
    }
}
