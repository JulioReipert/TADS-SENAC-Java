package testaFila;

public class TestaFila {

    public static void main(String[] args) {
        Fila f = new Fila(5);

        f.enfileirar(10);
        f.enfileirar(20);
        f.enfileirar(30);
        f.enfileirar(40);
        f.enfileirar(50);
        f.enfileirar(60);

        f.imprimirFila();

        System.out.println(f.desenfileirar());
        System.out.println(f.desenfileirar());
        System.out.println(f.desenfileirar());
        System.out.println(f.desenfileirar());
        System.out.println(f.desenfileirar());
        System.out.println(f.desenfileirar());

        f.imprimirFila();
    }
}
