package testaFila;

import java.util.Arrays;

public class FilaDomino {

    private int ini = 0, tam = 0, tamMax, fim = -1;
    private Object[] elem;

    public FilaDomino(int tamMax) {
        this.tamMax = tamMax;
        elem = new Object[tamMax];
    }

    public boolean estaVazia() {
        return tam == 0;
    }

    public boolean estaCheia() {
        return tam == tamMax;
    }

    public void enfileirar(Object valor) {
        if (estaCheia()) {
            System.out.println("ERRO: a fila ja esta cheia.");
        } else {
            tam++;
            fim++;
            elem[fim] = valor;
        }
    }

    public Object desenfileirar() {
        if (estaVazia()) {
            System.out.println("Erro: a fila ja esta vazia.");
            return -1;
        } else {
            Object aux = elem[0]; // para mostrar o elemento que foi removido
            for (int i = 0; i < (tam - 1); i++) {
                elem[i] = elem[i + 1];
            }
            elem[fim] = 0;
            tam--;
            fim--;
            return aux;
        }
    }

    public Object espiar() {
        if (estaVazia()) {
            System.out.println("ERRO: a fila esta vazia.");
            return -1;
        } else {
            return elem[0];
        }
    }

    public int tamanho() {
        return tam;
    }

    public void imprimirFila() {
        for (int i = 0; i < (tam - 1); i++) {
            System.out.print(elem[i] + " ");
        }
    }
}
