import java.util.Scanner;

public class ADO1 {
	static Scanner ler = new Scanner(System.in);
	static int a = 5;

	public static void main(String[] args) {

		int[] num = new int[a];
		System.out.println("Informe " + a + " números: ");
		for (int i = 0; i < a; i++) {
			num[i] = ler.nextInt();
		}
		// ex1(num);
		// ex2(num);
		// ex3(num);
		// ex4(num);
		 ex5(num);
	}

	public static void ex1(int[] numeros) {
		int soma = 0;
		for (int i = 0; i < a; i++) {
			soma += numeros[i];
		}
		System.out.println("A soma dos números é igual a: " + soma);
	}

	public static void ex2(int[] numeros) {
		int maior = -2147483648;
		for (int i = 0; i < a; i++) {
			if (numeros[i] > maior) {
				maior = numeros[i];
			}

		}
		System.out.println("O maior número dentre todos os informados é: " + maior);
	}

	public static void ex3(int[] numeros) {
		String verif = "não está";
		System.out.println(
				"Digite o elemento que deseja verificar se está presente dentre os informados anteriormente: ");
		int elemento = ler.nextInt();
		for (int i = 0; i < a; i++) {
			if (elemento == numeros[i]) {
				verif = "está";
				break;
			}
		}
		System.out.printf("O elemento digitado %s presente.%n", verif);
	}

	public static void ex4(int[] numeros) {
		int soma = 0, media;
		for (int i = 0; i < a; i++) {
			soma += numeros[i];
		}
		media = soma / a;
		System.out.println("O resultado do cálculo da média dos números informados é igual a: " + media);
	}

	public static void ex5(int[] numeros) {
		int menorNum = -2147483648, soma = 0;
		String verif = "estão";
		for (int i = 0; i < a; i++) {
			soma += numeros[i];
			if (menorNum <= numeros[i]) {
				menorNum = numeros[i];
			}
			if (soma - (a * numeros[i]) == 0) {
				verif = "não estão";
			} else if (menorNum > numeros[i]) {
				verif = "não estão";
			}
		}
		System.out.printf("Os elementos informados %s em ordem crescente.%n", verif);
	}
}
