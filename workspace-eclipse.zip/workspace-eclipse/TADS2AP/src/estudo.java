
public class estudo {

	public static void main(String[] args) {
		int num = 5;
		System.out.println('A');

	}
	int fatorial( int n ){
		if(n==0)
		return 1;
		else
		return n * fatorial(n - 1);
		}

}
