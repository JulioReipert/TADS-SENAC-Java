package aulasAP2;

import java.util.ArrayList;

public class listatarefas {
    
    public class ListaTarefas {
        public static void main(String[] args) {
            ArrayList<String> tarefas = new ArrayList<>();
            
            tarefas.add("Lavar as louças");
           
        }
    }
}
