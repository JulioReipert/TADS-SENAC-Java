package aulasAP2;

import java.util.ArrayList;
import java.util.Scanner;

public class LerIdades {

    public static void main(String[] args) {
        ArrayList<Integer> idades = new ArrayList<>();
        Scanner scan = new Scanner(System.in);

        while (true) {
            System.out.println("informe a idade:");
            int idade = scan.nextInt();
            if (idade < 0) {
                break;
            } else {
                idades.add(idade);
            }
        }
        for (int i : idades) {
            System.out.printf(i + ", ");
        }
    }
}
