package aulasAP2;


public class SomaMatriz {
 
    public static void main(String[] args) {
     int[][] matriz = {{1,2,3,4,5},{1,2,3,4,5}};   
     int linha = 5;
     int coluna = 2;
     
     /*int somaLinha = somaMatrizLinha(matriz, linha);
     int somaColuna = somaMatrizColuna( matriz,coluna);
     */
   
    }
    
    public static int somaMatrizLinha(int matriz[],int linha){
        
        if (linha == 0){
            return 0;
        }
        return matriz[linha - 1] + somaMatrizLinha(matriz, linha - 1);
    }
    
    public static int somaMatrizColuna(int matriz[], int coluna){
        
        if (coluna == 0){
            return 0;
        }
        return matriz[coluna - 1] + somaMatrizColuna(matriz,coluna - 1);
    }
}
