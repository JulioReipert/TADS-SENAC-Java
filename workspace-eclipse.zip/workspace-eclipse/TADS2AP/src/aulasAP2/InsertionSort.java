package aulasAP2;

import java.util.Arrays;

public class InsertionSort {

    public static void main(String[] args) {
        int[] vetorMain = {15, 78, -2, 35, -12, -34, 0};
        insertionSort(vetorMain);
    }

    public static void insertionSort(int[] vetor) {
        for (int i = 1; i < vetor.length; i++) {
            int aux = vetor[i];
            int j = i - 1;
            while ((j >= 0) && (vetor[j] > aux)) {
                vetor[j + 1] = vetor[j];
                j--;
            }
            vetor[j + 1] = aux;
        }
        System.out.println(Arrays.toString(vetor));
    }
}
