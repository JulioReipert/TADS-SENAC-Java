package aulasAP2;

public class SelectionSort {

    public static void main(String[] args) {
        int[] vetorMain = {10, 20, 32, 23, 15};
        selectionSort(vetorMain);
        printVetor(vetorMain);
    }

    public static void selectionSort(int[] vetor) {
        int aux = 0, index;
        for (int i = 0; i < (vetor.length - 1); i++) {
            index = i;
            for (int j = (i + 1); j < vetor.length; j++) {
                if (vetor[j] < vetor[index]) {
                    index = j;
                }
            }
            aux = vetor[i];
            vetor[i] = vetor[index];
            vetor[index] = aux;
        }
    }

    public static void printVetor(int[] vetor) {
        for (int i = 0; i < vetor.length; i++) {
            System.out.printf("%d\t", vetor[i]);
        }
    }
}
