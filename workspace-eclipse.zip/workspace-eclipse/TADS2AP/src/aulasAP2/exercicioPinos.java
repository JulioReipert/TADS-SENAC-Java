package aulasAP2;


public class exercicioPinos {

    public static void main(String[] args) {
        int linhas = 4;

        System.out.println(calcularPinosRecursivo(linhas));
        System.out.println(fatorial(linhas));
    }

    /*
    public static int calcularPinos(int linha) {

        int soma = 0;
        int tamanho = linha;
        
        for (int i = 0; i < tamanho; i++) {

            soma += linha;
            linha--;
        }

        return soma;
    }
     */
    
    public static int calcularPinosRecursivo(int linha) {
        if (linha == 1) {
            return 1;
        }
        return linha + calcularPinosRecursivo(linha - 1);
    }
    
    public static int fatorial (int n) {
        if (n == 0) {
            return 1;
        } 
        return n * fatorial(n - 1);
    }
    
}

 