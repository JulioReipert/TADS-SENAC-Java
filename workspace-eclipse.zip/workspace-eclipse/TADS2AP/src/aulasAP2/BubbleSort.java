package aulasAP2;

public class BubbleSort {

    public static void main(String[] args) {
        int vetorMain[] = {67, 45, 25, 13, 02};
        bubbleSort(vetorMain);
        printVetor(vetorMain);
    }

    public static void bubbleSort(int[] vetor) {
        int aux;
        for (int i = 0; i < vetor.length - 1; i++) {

            for (int j = 0; j < vetor.length - 1; j++) {
                if (vetor[j] > vetor[j + 1]) {
                    aux = vetor[j];
                    vetor[j] = vetor[j + 1];
                    vetor[j + 1] = aux;

                }
            }
        }
    }

    public static void printVetor(int[] vetor) {
        System.out.println("\nResultado:");
        for (int i = 0; i < vetor.length; i++) {

            System.out.println(vetor[i]);
        }
    }
}
