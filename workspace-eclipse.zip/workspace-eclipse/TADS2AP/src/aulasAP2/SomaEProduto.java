package aulasAP2;


public class SomaEProduto {

       public static void main(String[] args) {
        int[] vetor = {1,2,3,4,5};
        int tamanho = vetor.length;
        int[] resultado = somaEProduto(vetor,tamanho);
        
        System.out.println("Somatorio: "+resultado[0]);
        System.out.println("Produtorio: "+resultado[1]);
    
        }

    public static int[] somaEProduto(int[] vetor, int tamanho){
        int[] resultado = new int[2];
        resultado[0] = soma(vetor, tamanho);
        resultado[1] = produto(vetor, tamanho);
        return resultado; 
    }

    public static int soma(int[] vetor, int tamanho){
    
        if(tamanho == 0) {
            return 0;
        } 
        return vetor[tamanho - 1] + soma(vetor, tamanho - 1);
        } 
        
    public static int produto(int[] vetor, int tamanho){
        
        if(tamanho == 0) {
            return 1;
        } 
        return vetor[tamanho - 1] * produto(vetor,tamanho - 1);
    }
}
