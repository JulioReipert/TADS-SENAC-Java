package aulasAP2;

import java.util.Arrays;

public class BuscaBinaria {

    public static void main(String[] args) {
        int[] vetorMain = {1, 2, 4, 5, 6, 8, 10, 11, 12, 15, 16, 17};
        System.out.println("posicao do elento selecionado no vetor: " + buscaBinaria(vetorMain, 15));
    }

    public static int buscaBinaria(int[] vetor, int x) {
        int inicio = 0, fim = vetor.length - 1;
        while (inicio <= fim) {
            int meio = (int) (inicio + fim) / 2; // Cast (int): transforme qualquer resultado da conta em int
            if (vetor[meio] == x) {return meio;}
            if (vetor[meio] > x) {fim = meio - 1;}
            if (vetor[meio] < x) {inicio = meio + 1;}
        }
        return -1;
    }
}
