
package Exercicio3;

public class Excercicio3main {
    public static void main(String[] args) {
        Biblioteca bib = new Biblioteca();
        
        Livro livro1 = new Livro("Diário de um Banana", "abc123");
        bib.adicionarLivro(livro1);
        
        bib.adicionarLivro(new Livro ("Aprenda Java em 30 dias", "def456"));
        
        bib.imprimirLivros();
    }
}
