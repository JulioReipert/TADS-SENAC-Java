package Exercicio3;

public class Livro {

    private String nome;
    private String isbn;

    public Livro(String nome, String isbn) {
        this.nome = nome;
        this.isbn = isbn;
    }

    @Override
    public String toString() {
        return "Livro: " + nome + ", isbn=" + isbn;
    }

}
