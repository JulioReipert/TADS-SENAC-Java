package Exercicio3;

import java.util.ArrayList;

public class Biblioteca {

    ArrayList<Livro> livros = new ArrayList<>();

    public void adicionarLivro(Livro objetoLivro) {
        livros.add(objetoLivro);
    }
    public void imprimirLivros() {
//        for (Livro : livros) {
//        System.out.printf("a");
//    }
    }
}
