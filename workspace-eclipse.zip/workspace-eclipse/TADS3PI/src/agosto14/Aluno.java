package agosto14;

import javax.swing.JOptionPane;

public class Aluno {
	String nome, ra;
	short idade;
	double nota1, nota2;

	// métodos de gravação
	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setRa(String ra) {
		this.ra = ra;
	}

	public void setIdade(short idade) {
		this.idade = idade;
	}

	public void setNota1(double nota1) {
		this.nota1 = nota1;
	}

	public void setNota2(double nota2) {
		this.nota2 = nota2;
	}

	// Métodos de leitura
	public String getRa() {
		return ra;
	}

	public String getNome() {
		return nome;
	}

	public int getIdade() {
		return idade;
	}

	public double getNota1() {
		return nota1;
	}

	public double getNota2() {
		return nota2;
	}

	public void imprimir() {
		System.out.println("RA: " + getRa() + "\tNome: " + getNome() + "\n1ª Nota: " + getNota1() + "\n2ª Nota: "
				+ getNota2() + "\nMédia = " + (getNota1() + getNota2()) / 2);
		JOptionPane.showMessageDialog(null,
				"RA: " + getRa() + "\nNome: " + getNome() + "\n1ª Nota: " + getNota1() + "\n2ª Nota: "
						+ getNota2() + "\nMédia = " + calcularMedia());
	}

	private double calcularMedia() {
		double media = (getNota1()+getNota2())/2;
		return media;
	}
}
