// Julio Leme Reipert TADS 3MA

package ado1;

import javax.swing.JOptionPane;

public class Ado1 {
	static int ordem;

	public static void main(String[] args) {
		ordem = Integer.parseInt(JOptionPane.showInputDialog(null, "Insira a ordem da matriz quadrada:",
				"Gerar matriz", JOptionPane.PLAIN_MESSAGE));
		int[][] matrizQuadrada = new int[ordem][ordem];
		for (int i = 0; i < matrizQuadrada.length; i++) {
			for (int j = 0; j < matrizQuadrada[i].length; j++) {
				matrizQuadrada[i][j] = Integer.parseInt(JOptionPane.showInputDialog(null,
						String.format("Insira o valor da matriz[%d] [%d]", i + 1, j + 1),
						"Gerar matriz", JOptionPane.PLAIN_MESSAGE));
			}
		}
		JOptionPane.showMessageDialog(null,
				"Soma de todos os números: " + somaMatriz(matrizQuadrada) + "\nMaior número: "
						+ maiorNumero(matrizQuadrada) + "\nMenor número: " + menorNumero(matrizQuadrada)
						+ "\nSoma diagonal principal: " + diagonalPrincipal(matrizQuadrada)
						+ "\nSoma diagonal secundária: " + diagonalSecundaria(matrizQuadrada),
				"Gerar matriz", JOptionPane.PLAIN_MESSAGE);
	}

	public static int somaMatriz(int matriz[][]) {
		int soma = 0;
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				soma = soma + matriz[i][j];
			}
		}
		return soma;
	}

	public static int maiorNumero(int matriz[][]) {
		int maiorNumero = Integer.MIN_VALUE;
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				if (matriz[i][j] > maiorNumero) {
					maiorNumero = matriz[i][j];
				}
			}
		}
		return maiorNumero;
	}

	public static int menorNumero(int matriz[][]) {
		int menorNumero = Integer.MAX_VALUE;
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				if (matriz[i][j] < menorNumero) {
					menorNumero = matriz[i][j];
				}
			}
		}
		return menorNumero;
	}

	public static int diagonalPrincipal(int matriz[][]) {
		int soma = 0;
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				if (i == j) {
					soma += matriz[i][j];
				}
			}
		}
		return soma;
	}

	public static int diagonalSecundaria(int matriz[][]) {
		int soma = 0;
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				if (i + j == ordem - 1) {
					soma += matriz[i][j];
				}
			}
		}
		return soma;
	}
}