package agosto21;

public class Carro {
	protected int litrosNoTanque;
	protected boolean carroLigado;

	public void encherTanque(int litros) {
		litrosNoTanque = litros;
	}
}

