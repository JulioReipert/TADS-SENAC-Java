package agosto21;

import javax.swing.JOptionPane;

public class TestePessoa {

	public static void main(String[] args) {
		int resp = 0;
		do {
		Pessoa joao = new Pessoa(JOptionPane.showInputDialog("Digite o nome:"),
				JOptionPane.showInputDialog("Digite o endereço:"),
				Integer.parseInt(JOptionPane.showInputDialog("Digite a idade:")));

		JOptionPane.showMessageDialog(null,
				String.format("Nome: %s\nIdade: %d\nEndereço: %s", joao.getNome(), joao.getIdade(), joao.getEndereco()),
				"Informações da pessoa", JOptionPane.INFORMATION_MESSAGE);
		
		resp = JOptionPane.showConfirmDialog(null, "Deseja continuar?");

		} while (resp == 0);
	}

}