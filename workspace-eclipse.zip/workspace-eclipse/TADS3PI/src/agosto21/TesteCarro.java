package agosto21;

public class TesteCarro {

	public static void main(String[] args) {
		Carro carro = new Carro();
		carro.encherTanque(10);

	}
}
