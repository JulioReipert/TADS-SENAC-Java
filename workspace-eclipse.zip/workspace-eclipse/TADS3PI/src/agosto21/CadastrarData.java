package agosto21;

import javax.swing.JOptionPane;

public class CadastrarData {

	public static void main(String[] args) {
		String isBissexto;
		Data data = new Data(Integer.parseInt(JOptionPane.showInputDialog("Digite o ano:")),
				Byte.parseByte(JOptionPane.showInputDialog("Digite o mês:")),
				Byte.parseByte(JOptionPane.showInputDialog("Digite o dia:")));

		JOptionPane.showMessageDialog(null, String.format("%d / %d / %d", data.getDia(), data.getMes(), data.getAno()));

		if (data.isAnoBissexto()) {
			isBissexto = "É bissexto";
		} else {
			isBissexto = "Não é bissexto";
		}
		JOptionPane.showMessageDialog(null, isBissexto);
	}
}
