package agosto21;

public class Data {
	public Data(int ano, byte mes, byte dia) {
		this.ano = ano;
		this.mes = mes;
		this.dia = dia;
	}

	private int ano;
	private byte mes;
	private byte dia;

	public int getAno() {
		return ano;
	}

	public void setAno(int a) {
		if (a > 0) {
			ano = a;
		} else {
			System.err.println("Ano inválido");
		}
	}

	public byte getDia() {
		return dia;
	}

	public void setDia(byte d) {
		if (d > 0 && d <= 31) {
			dia = d;
		} else {
			System.err.println("Dia inválido");
		}
	}

	public byte getMes() {
		return mes;
	}

	public void ajustarMes(byte m) {
		if (m > 0 && m <= 12) {
			mes = m;
		} else {
			System.err.println("Mês inválido");
		}
	}

	public boolean isAnoBissexto() {
		if (((ano % 4 == 0) && (ano % 100 != 0)) || (ano % 400 == 0)) {
			return true;
		} else {
			return false;
		}
	}
}
