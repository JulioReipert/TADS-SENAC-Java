import java.util.Scanner;

public class ExemploIf2 {

	public static void main(String[] args) {
		// variáveis
		double media;
		String classif;
		Scanner leia = new Scanner(System.in);
		// entrada de dados
		System.out.println("Informe a média");
		media = leia.nextDouble();
		if (media < 0 || media > 10) {
			System.err.println("Média inválida");
		} else {
			if (media < 2) {
				classif = "E";
			} else if (media < 4) {
				classif = "D";
			} else if (media < 6) {
				classif = "C";
			} else if (media < 8) {
				classif = "B";
			} else {
				classif = "A";
			}
			System.out.println("Classificação " + classif);
			leia.close();
		}

	}

}
