import java.util.Scanner;

public class ExemploIfMelhorado {

	public static void main(String[] args) {
		// variáveis
		double n1, n2, media;
		Scanner leia = new Scanner(System.in);
		// entrada de dados
		System.out.println("Informe as notas");
		n1 = leia.nextDouble();
		// verificar nota inválida
		if (n1 < 0 || n1 > 10) {
			System.err.println("Primeira nota inválida");
		} else {
			n2 = leia.nextDouble();
			// verificar nota inválida
			if (n2 < 0 || n2 > 10) {
				System.err.println("Segunda nota inválida");
			} else {
				// verificar média inválida
				media = (n1 + n2) / 2;
				if (media >= 5) {
					System.out.println("Aluno aprovado");
				} else {
					System.out.println("Aluno reprovado");
					System.out.println("Se ferrou");
				}
				System.out.println("média = " + media);
				// exemplo operador lógico
				if (media >= 8 && media <= 10) {
					System.out.println("Você tirou entre 8,0 e 10,0");
					leia.close();
				}
			}
		}
	}

}
