import java.util.Scanner;

public class ExemploIf {

	public static void main(String[] args) {
		// variáveis
		double n1, n2, media;
		Scanner leia = new Scanner(System.in);
		// entrada de dados
		System.out.println("Informe as notas");
		n1 = leia.nextDouble();
		n2 = leia.nextDouble();
		media = (n1 + n2) / 2;
		// verificar média inválida
		if (media < 0 || media > 10) {
			System.err.println("Média Invalida");
		} else {
			if (media >= 5) {
				System.out.println("Aluno aprovado");
			} else {
				System.out.println("Aluno reprovado");
				System.out.println("Se ferrou");
			}
			System.out.println("média = " + media);
			// exemplo operador lógico
			if (media >= 8 && media <= 10) {
				System.out.println("Você tirou entre 8,0 e 10,0");
			}
		}
		leia.close();
	}
}
