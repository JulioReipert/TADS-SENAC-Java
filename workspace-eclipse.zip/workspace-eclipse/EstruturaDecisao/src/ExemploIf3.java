import java.util.Scanner;

public class ExemploIf3 {

	public static void main(String[] args) {
		// variáveis
		double n1, n2, media;
		Scanner leitor = new Scanner(System.in);
		// entrada de dados
		n1 = leitor.nextDouble();
		n2 = leitor.nextDouble();
		media = (n1 + n2) / 2;
		// exibir se está aprovado ou reprovado
		System.out.println(media >= 5 ? "Aprovado" : "Reprovado");
		leitor.close();
	}
}
