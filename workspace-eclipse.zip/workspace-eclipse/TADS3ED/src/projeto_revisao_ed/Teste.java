package projeto_revisao_ed;

public class Teste {

	public static void main(String[] args) throws Exception {
		Vetor vetor = new Vetor(5);

		vetor.adiciona("Elemento 1");
		vetor.adiciona("Elemento 2");

		System.out.println("A quantidade de informações no vetor é: " + vetor.tamanho());

		System.out.println("Dados do Vetor: " + vetor.toString());

		System.out.println("resultado da busca por elemento: " + vetor.busca(1));

		System.out.println("resultado da busca por posição: " + vetor.busca1("Elemento 2"));
		
		System.out.println(vetor.adicionaInicio(0, "Elemento 0"));
		
		System.out.println("A quantidade de informações no vetor é: " + vetor.tamanho());

		System.out.println("Dados do Vetor: " + vetor.toString());

	}
}