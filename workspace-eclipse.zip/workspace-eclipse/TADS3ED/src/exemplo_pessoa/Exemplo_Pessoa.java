package exemplo_pessoa;

public class Exemplo_Pessoa {

	public static void main(String[] args) {
		Pessoa p1 = new Pessoa();
		Pessoa p2 = new Pessoa("Claudio", 52, "Emai@teste.com");
		
		System.out.println("Dados da P1" + p1.toString());
		
		System.out.println("Dados da P2" + p2.toString());
	}
}
