package exemplo_pessoa;

public class Pessoa {

}
