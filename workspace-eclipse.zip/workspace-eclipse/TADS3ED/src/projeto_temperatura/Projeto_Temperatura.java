package projeto_temperatura;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class Projeto_Temperatura {

	public static void main(String[] args) {
		double[] temperatura = new double[7];
		double soma = 0, media = 0;
		int dias_acima = 0, dias_abaixo = 0;

		Scanner dados = new Scanner(System.in);

		for (int i = 0; i < temperatura.length; i++) {
			System.out.println("Digite a " + (i + 1) + "ª Temperatura:");
			temperatura[i] = dados.nextDouble();
			soma = soma + temperatura[i];
		}
		media = soma / 7;
		for (int i = 0; i < temperatura.length; i++) {
			if (temperatura[i] > media) {
				dias_acima++;
			}
			if (temperatura[i] < media) {
				dias_abaixo++;
			}
		}

		System.out.println("A média de temperatura é: " + media + "\ndias que a temperatura ficou acima da média: "
				+ dias_acima + "\ndias que a temperatura ficou abaixo da média: " + dias_abaixo);

	}

}
