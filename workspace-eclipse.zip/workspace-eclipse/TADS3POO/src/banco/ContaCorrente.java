package banco;

public class ContaCorrente {
	public double saldo = 0.00;
	public String titular; // para questões de alta coesão seria melhor criar uma classe a parte
	public double checkEspecial = 1000;
	public String agencia;
	public String nrConta;
	public String banco;

	public void depositar(double valor) {
		this.saldo += valor;
	}

	public String exibirSaldo() {
		String saldoFormat;
		saldoFormat = String.format("R$ %7.2f", this.saldo); // o return pode vir antes de saldoFormat nessa linha.
		return saldoFormat;
	}

	private boolean verificarSaldo(double valor) {
		/*
		 * if (valor <= (this.saldo + this.checkEspecial)) { return true; } else {
		 * return false; }
		 */ // substituído por apenas a linha abaixo
		return valor <= (this.saldo + this.checkEspecial);
	}

	public boolean sacar(double valorSaque) {
		if (verificarSaldo(valorSaque)) {
			this.saldo -= valorSaque;
			return true;
		} // não precisa do else
		return false;
	}

	public boolean transferir(double valor, ContaCorrente destino) {
		if (verificarSaldo(valor)) {
			this.saldo -= valor;
			destino.saldo += valor;
			return true;
		}
		return false;
	}
}