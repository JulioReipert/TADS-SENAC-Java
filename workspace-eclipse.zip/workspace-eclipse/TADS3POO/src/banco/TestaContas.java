package banco;

public class TestaContas {

	public static void main(String[] args) {
		// criando uma conta
		ContaCorrente c1 = new ContaCorrente();
		c1.banco = "Itaú";
		c1.agencia = "0755";
		c1.nrConta = "1234-5";
		c1.titular = "Ana Maria";
		System.out.println("Saldo da Ana Maria: " + c1.exibirSaldo());
		c1.depositar(200);
		System.out.println("Saldo da Ana Maria: " + c1.exibirSaldo());
		if (c1.sacar(1201)) { // valor do saldo + cheque especial + 1 
			System.out.println("Saque realizado com sucesso");
		} else {
			System.err.println("Não foi possível realizar o saque");
		}
		System.out.println("Saldo da Ana Maria: " + c1.exibirSaldo());
		
		ContaCorrente c2 = new ContaCorrente();
		c2.banco = "Bradesco";
		c2.agencia = "0622";
		c2.nrConta = "4213-6";
		c2.titular = "João Paulo";
		System.out.println("Saldo do João Paulo: " + c2.exibirSaldo());
		
		if (c1.transferir(120, c2)) {
			System.out.println("Saque realizado com sucesso");
		} else {
			System.err.println("Não foi possível realizar a transferência");
		}
		System.out.println("Saldo da Ana Maria: " + c1.exibirSaldo());
		System.out.println("Saldo do João Paulo: " + c2.exibirSaldo());
	}
}
