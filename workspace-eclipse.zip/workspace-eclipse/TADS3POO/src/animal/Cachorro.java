package animal;

public class Cachorro {
// atributos (estado)
	public String nome;
	public String raca;
	private boolean fome = true; // só pode ser alterado por meio das ações, caso estiver fora da mesma classe

	// metodos (comportamento)
	public void info() {
		System.out.printf("Nome: %s%nRaça: %s%n", this.nome, this.raca);
		// condição ? valor se v : valor se f (operação ternária)
		System.out.println(fome == true ? "Estou com fome" : "Não estou com fome");
	}
	/*
	 * if (fome) { System.out.println("Estou com fome"); } else {
	 * System.out.println("Não estou com fome");
	 */ // Substituído por operação ternária

	public void latir(int latidos) {
		System.out.println(this.nome + " latindo:");

		for (int i = 0; i < latidos; i++) {
			System.out.println("Au Au!");
		}
	}

	public void comer() {
		if (fome) {
			fome = false;
		}
	}

	public void dormir() {
		System.out.println("zzzzzzzzzzz");
		fome = true;
	}

	private void chorar() {
		System.out.println("uim uim uim uim :(");
	}

	public void morder(Cachorro dog) {
		dog.chorar(); // só posso acessar o metodo chorar (privado) pois está na mesma classe
		dog.fome = true;
	}
}
