package Avaliacao01;

import java.util.Scanner;

public class Ex2 {

	public static void main(String[] args) {
		String placa, CPF, escolhaCPF;
		int hE, hS, mE, mS, qtdHoras, qtdMinutos;
		double valor;
		Scanner leia = new Scanner(System.in);
		System.out.println("Informe a placa do veículo");
		placa = leia.nextLine();
		System.out.println("Informe a hora e os minutos da entrada:");
		hE = leia.nextInt();
		mE = leia.nextInt();
		System.out.println("Informe a hora e os minutos da saída:");
		hS = leia.nextInt();
		mS = leia.nextInt();
		qtdHoras = hS - hE;
		if (hS < hE) {
			qtdHoras += 24;
		}
		qtdMinutos = mS - mE;
		if (mS < mE) {
			qtdMinutos += 60;
			qtdHoras--;
		}
		if (qtdHoras == 0 && qtdMinutos <= 15) {
			valor = 0;
		} else if (qtdHoras == 0 && qtdMinutos > 15) {
			valor = 7;
		} else if (qtdHoras == 1 && qtdMinutos == 00) {
			valor = 7;
		} else if (qtdHoras == 1 && qtdMinutos <= 59) {
			valor = 12;
		} else if (qtdHoras == 2 && qtdMinutos == 00) {
			valor = 12;
		} else if (qtdHoras <= 3 && qtdMinutos <= 59) {
			valor = 18;
		} else if (qtdHoras == 4 && qtdMinutos == 00) {
			valor = 18;
		} else if (qtdHoras <= 5 && qtdMinutos <= 59) {
			valor = 20;
		} else if (qtdHoras == 6 && qtdMinutos == 00) {
			valor = 20;
		} else {
			valor = 28;
		}
		System.out.println("Deseja inserir o CPF? (S para Sim e N para Não)");
		escolhaCPF = leia.next();
		if (!escolhaCPF.equalsIgnoreCase("S") && !escolhaCPF.equalsIgnoreCase("N")) {
			System.out.println("Responda apenas com S ou N.");
		} else if (escolhaCPF.equalsIgnoreCase("S")) {
			System.out.println("Informe o CPF:");
			CPF = leia.next();
			System.out.printf(
					"RECIBO DO ESTACIONAMENTO %nRede Pare Bem - Shop Gaste Bem %nPlaca: %s %nEntrada: %02d hora(s) e %02d minuto(s) %nSaída: %d hora(s) e %d minuto(s) %nPermanência: %d hora(s) e %d minuto(s) %nValor: %.2f %nCPF: %s",
					placa, hE, mE, hS, mS, qtdHoras, qtdMinutos, valor, CPF);
		} else {
			System.out.printf(
					"RECIBO DO ESTACIONAMENTO %nRede Pare Bem - Shop Gaste Bem %nPlaca: %s %nEntrada: %d hora(s) e %d minuto(s) %nSaída: %d hora(s) e %d minuto(s) %nPermanência: %d hora(s) e %d minuto(s) %nValor: %.2f",
					placa, hE, mE, hS, mS, qtdHoras, qtdMinutos, valor);

		}

	}

}
