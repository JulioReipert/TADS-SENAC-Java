package Lista3ADO03;

import java.util.Random;
import java.util.Scanner;

public class lista3ADO03 {
	static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		// ex01();
		// ex02();
		// ex03();
		// ex04();
		// ex05();
		// ex06();
		// ex07();
		// ex08();
		// ex09();
		// ex10();
		// ex11();

		// ex14();
		// ex15();
		// ex16();
		ex17();
	}

	public static void ex01() {
		for (int i = 50; i <= 9500; i++) {
			if (i % 3 == 0) {
				System.out.println(i);
			}
		}
	}

	public static void ex02() {
		for (int i = 1; i <= 250; i++) {
			if (i % 10 == 0) {
				System.out.printf("%d é múltiplo de 10.%n", i);
				continue;
			}
			System.out.println(i);
		}
	}

	public static void ex03() {
		int soma = 0;
		for (int i = 1; i <= 100; i++) {
			soma = soma + i;
			System.out.println(soma);

		}
	}

	public static void ex04() {
		int soma = 0, fim;
		System.out.println("Informe o fim:");
		fim = scan.nextInt();
		for (int i = 1; i <= fim; i++) {
			soma = soma + i;
			System.out.println(soma);
		}
	}

	public static void ex05() {
		int soma = 0;
		for (int i = 5; i <= 75; i += 5) {
			soma = soma + i;
			System.out.println(soma);
		}
	}

	public static void ex06() {
		int inicio, fim, soma = 0;
		System.out.println("Informe o número inicial e o final:");
		inicio = scan.nextInt();
		fim = scan.nextInt();
		for (int i = inicio; i <= fim; i += 5) {
			soma = soma + i;
			System.out.println(soma);
		}
	}

	public static void ex07() {
		double aumento = 0.015, sAtual = 1000;
		for (double i = 2011; i <= 2023; i++) {
			sAtual = sAtual + (sAtual * aumento);
			System.out.printf("%.2f%n", sAtual);
			aumento = aumento * 2;
		}
	}

	public static void ex08() {
		int mes = 0;
		double sCarlos;
		System.out.println("Informe o salário de Carlos:");
		sCarlos = scan.nextInt();
		double sJoao = sCarlos / 3;
		do {
			sCarlos = sCarlos + (sCarlos * 0.02);
			sJoao = sJoao + (sJoao * 0.05);
			mes++;
		} while (sJoao < sCarlos);
		System.out.printf("Número de meses para o valor de João igualar ou ultrapassar o de Carlos: %d%n", mes);

	}

	public static void ex09() {
		int num1 = 1, num2 = 0, negativos = 0;
		while (num1 != 0) {
			System.out.println(
					"Informe um número inteiro diferente de 0 ou informe 0 para somar os números positivos informados e contar a quantidade de números negativos:");
			num1 = scan.nextInt();
			if (num1 >= 0) {
				num2 = num1 + num2;
			} else {
				negativos++;
			}
		}
		System.out.printf("Soma dos números positivos: %d%nQuantidade de números negativos informados: %d%n", num2,
				negativos);
	}

	public static void ex10() {
		double nota = 0;
		String status;
		System.out.println("Informe a nota do aluno:");
		nota = scan.nextDouble();
		while (nota < 0 || nota > 10) {
			System.err.println("Informe uma nota entre 0 e 10:");
			nota = scan.nextDouble();
		}
		if (nota < 5) {
			status = "reprovado";
		} else if (nota >= 6) {
			status = "aprovado";
		} else {
			status = "de recuperação";
		}
		System.out.printf("O aluno está %s.", status);
	}

	public static void ex11() {
		double salario, taxa, imposto, novoSalario, aumento;
		int opcao = 1;
		String classif, erro = "";
		while (opcao == 1 || opcao == 2 || opcao == 3 || erro.equals("Opção inválida.")) {
			System.out.printf(
					"----- Menu de opções ----- %n1.Imposto %n2.Novo salário %n3.Classificação %n4.Finalizar o programa %nDigite a opção desejada. %n-----------------------------------%n");
			opcao = scan.nextInt();
			switch (opcao) {
			case 1:
				System.out.println("Informe o salário:");
				salario = scan.nextDouble();
				if (salario <= 1500) {
					taxa = 0.05;
				} else if (salario >= 1500.01 && salario <= 3000) {
					taxa = 0.1;
				} else {
					taxa = 0.15;
				}
				imposto = salario * taxa;
				System.out.printf("O imposto é de %.2f.%n%n", imposto);
				break;
			case 2:
				System.out.println("Informe o salário:");
				salario = scan.nextDouble();
				if (salario > 4500) {
					aumento = 250;
				} else if (salario >= 3000.01 && salario <= 4500) {
					aumento = 200;
				} else if (salario >= 2000.01 && salario <= 3000) {
					aumento = 150;
				} else {
					aumento = 130;
				}
				novoSalario = salario + aumento;
				System.out.printf("O novo salário é de %.2f.%n%n", novoSalario);
				break;
			case 3:
				System.out.println("Informe o salário:");
				salario = scan.nextDouble();
				if (salario > 3000) {
					classif = "Bem remunerado";
				} else {
					classif = "Mal remunerado";
				}
				System.out.printf("Classificação: %s.%n%n", classif);
				break;
			case 4:
				System.out.println("Programa finalizado.");
				break;
			default:
				erro = "Opção inválida.";
				System.err.printf("%s%n%n", erro);
				break;
			}
		}
	}

	public static void ex14() {
		int resultado;
		for (int i = 1; i <= 10; i++) {
			System.out.printf("Tabuada do %d:%n", i);
			for (int j = 1; j <= 10; j++) {
				resultado = i * j;
				System.out.printf("%d x %d = %d%n", i, j, resultado);
			}
			System.out.println();
		}
	}

	public static void ex15() {
		// O exercício pede para que os dados sejam recebidos, porém já adicionei os
		// dados de forma randômica para agilizar a visualização dos resultados.
		int totalTimes = 5, totalJogadoresPorTime = 15, jogadoresMenoresDe18 = 0, jogadoresMaisDe80Kg = 0;
		double totalAlturas = 0, somaIdadesTime = 0, mediaIdadesTime = 0, mediaAlturas = 0, percentualMaisDe80Kg = 0,
				media1 = 0, media2 = 0, media3 = 0, media4 = 0, media5 = 0;

		for (int time = 1; time <= totalTimes; time++) {
			for (int jogador = 1; jogador <= totalJogadoresPorTime; jogador++) {
				Random rand = new Random();
				int idadeAleat = rand.nextInt(16, 36);
				double pesoAleat = rand.nextDouble(60, 91), alturaAleat = rand.nextDouble(1.65, 1.91);
				System.out.println("Time " + time + ", Jogador " + jogador);
				System.out.println("Idade: " + idadeAleat);
				int idade = idadeAleat;
				System.out.printf("Peso (em Kg): %.1f%n", pesoAleat);
				double peso = pesoAleat;
				System.out.printf("Altura (em metros): %.2f%n%n", alturaAleat);
				double altura = alturaAleat;

				somaIdadesTime += idade;
				totalAlturas += altura;

				if (idade < 18) {
					jogadoresMenoresDe18++;
				}

				if (peso > 80) {
					jogadoresMaisDe80Kg++;
				}
			}

			mediaIdadesTime = somaIdadesTime / totalJogadoresPorTime;
			if (time == 1) {
				media1 = mediaIdadesTime;
				somaIdadesTime = 0;
			} else if (time == 2) {
				media2 = mediaIdadesTime;
				somaIdadesTime = 0;
			} else if (time == 3) {
				media3 = mediaIdadesTime;
				somaIdadesTime = 0;
			} else if (time == 4) {
				media4 = mediaIdadesTime;
				somaIdadesTime = 0;
			} else {
				media5 = mediaIdadesTime;
				somaIdadesTime = 0;
			}
		}

		mediaAlturas = totalAlturas / (totalTimes * totalJogadoresPorTime);
		percentualMaisDe80Kg = (jogadoresMaisDe80Kg * 100) / (totalTimes * totalJogadoresPorTime);
		System.out.printf(
				"Jogadores com idade inferior a 18 anos: %d jogadores.%nMédia de idade do time 1: %.0f anos.%nMédia de idade do time 2: %.0f anos.%nMédia de idade do time 3: %.0f anos.%nMédia de idade do time 4: %.0f anos.%nMédia de idade do time 5: %.0f anos.%nMédia das alturas de todos os jogadores: %.2fm.%nPercentual de jogadores com mais de 80 Kg: %.0f%%.%n",
				jogadoresMenoresDe18, media1, media2, media3, media4, media5, mediaAlturas, percentualMaisDe80Kg);
	}

	public static void ex16() {
		int num = 0, numMaior = 0, numMenor = 0;
		while (num >= 0) {
			System.out.println(
					"Informe um número inteiro positivo ou informe um número negativo para mostrar o maior e menor número dentre os já informados:");
			num = scan.nextInt();
			if (num >= numMaior) {
				numMaior = num;
			} else {
				numMenor = num;
			}
		}
		System.out.printf("Maior número informado: %d %nMenor número informado: %d", numMaior, numMenor);
	}

	public static void ex17() {
		int num = 0, maior = Integer.MIN_VALUE, menor = Integer.MAX_VALUE, media = 0, pares = 0, divisiveisPor5 = 0;
		for (int i = 0; i < 15; i++) {
			System.out.printf("informe o %dº número:%n", i+1);
			num = scan.nextInt();
			media += num;
			if (num >= maior) {
				maior = num;
				
			 if (num < menor) {
				menor = num;
			}
			if (num % 2 == 0) {
				pares++;
			}
			if (num % 5 == 0) {
				divisiveisPor5++;
			}
		}
		media = media / 15;
		
	}
		System.out.printf(
				"Menor número informado: %d%nMaior número informado: %d%nMédia dos números digitados: %d%nQuantidade de números pares informados: %d%nQuantidade de números divisíveis por 5 informados: %d%n",
				menor, maior, media, pares, divisiveisPor5);
}
}