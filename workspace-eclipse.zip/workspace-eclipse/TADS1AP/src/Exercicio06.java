import java.util.Scanner;

public class Exercicio06 {

	public static void main(String[] args) {
		double sBruto, sLiquido, sGrat;
		Scanner ler = new Scanner(System.in);
		System.out.println("Cálculo de salário líquido com gratificação de 10% e desconto de 15% após gratificação.");
		System.out.println("Informe o salário bruto:");
		sBruto = ler.nextDouble();
		sGrat = sBruto + (sBruto * 0.10);
		sLiquido = sGrat - (sGrat * 0.15);
		System.out.printf("Seu salário líquido é igual a %.2f.", sLiquido);
		ler.close();
	}

}
