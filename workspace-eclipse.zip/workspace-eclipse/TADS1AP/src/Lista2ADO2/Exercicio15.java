package Lista2ADO2;

import javax.swing.JOptionPane;

public class Exercicio15 {

	public static void main(String[] args) {
		int nota1, nota2, nota3, nota4, media, aulas, qtdPresenca, presencaTaxa;
		String premio;
		nota1 = Integer.parseInt(
				JOptionPane.showInputDialog(null, "Informe a primeira nota:", "1ª nota", JOptionPane.QUESTION_MESSAGE));
		nota2 = Integer.parseInt(
				JOptionPane.showInputDialog(null, "Informe a segunda nota:", "2ª nota", JOptionPane.QUESTION_MESSAGE));
		nota3 = Integer.parseInt(
				JOptionPane.showInputDialog(null, "Informe a terceira nota:", "3ª nota", JOptionPane.QUESTION_MESSAGE));
		nota4 = Integer.parseInt(
				JOptionPane.showInputDialog(null, "Informe a quarta nota:", "4ª nota", JOptionPane.QUESTION_MESSAGE));
		media = (nota1 + nota2 + nota3 + nota4) / 4;
		aulas = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe a quantidade de aulas dadas:",
				"Aulas dadas", JOptionPane.QUESTION_MESSAGE));
		qtdPresenca = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe a quantidade de presenças:",
				"Presença", JOptionPane.QUESTION_MESSAGE));
		presencaTaxa = (qtdPresenca * 100) / aulas;
		if (media < 70 && presencaTaxa < 90) {
			premio = "Não há prêmios";
		} else if (media > 80 && presencaTaxa == 100) {
			premio = "Seu prêmio é: Excursão";
		} else if (media > 80 || presencaTaxa == 100) {
			premio = "Seu prêmio é: Camisa";
		} else if (media > 70 && presencaTaxa >= 90) {
			premio = "Seu prêmio é: Squeeze";
		} else {
			premio = "Seu prêmio é: Caneta personalizada";
		}
		JOptionPane.showMessageDialog(null, String.format("%s.", premio), "Premiação", JOptionPane.INFORMATION_MESSAGE);

	}
}
