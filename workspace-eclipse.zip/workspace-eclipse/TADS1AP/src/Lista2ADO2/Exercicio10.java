package Lista2ADO2;

import javax.swing.JOptionPane;

public class Exercicio10 {

	public static void main(String[] args) {
		int x, y, z;
		String triangulo;
		JOptionPane.showMessageDialog(null,
				"Cálculo que verifica se 3 valores podem formar um triângulo e se sim, informar o seu tipo.",
				"Exercício 10", JOptionPane.PLAIN_MESSAGE);
		x = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o primeiro valor:", "1º Valor",
				JOptionPane.QUESTION_MESSAGE));
		y = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o segundo valor:", "2º Valor",
				JOptionPane.QUESTION_MESSAGE));
		z = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o terceiro valor:", "3º Valor",
				JOptionPane.QUESTION_MESSAGE));
		if (x < y + z && y < x + z && z < x + y) {
			if (x == y && x == z) {
				triangulo = "equilátero";
			} else if (x == y) {
				triangulo = "isóceles";
			} else if (x == z) {
				triangulo = "isóceles";
			} else if (y == z) {
				triangulo = "isóceles";
			} else {
				triangulo = "escaleno";
			}
			JOptionPane.showMessageDialog(null, "O tipo do triângulo é " + triangulo + ".", "Tipo do triângulo",
					JOptionPane.INFORMATION_MESSAGE);
		} else
			JOptionPane.showMessageDialog(null, "Não é possível formar um triângulo.", "Erro",
					JOptionPane.ERROR_MESSAGE);
	}

}
