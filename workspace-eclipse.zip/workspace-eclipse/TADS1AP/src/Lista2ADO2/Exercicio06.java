package Lista2ADO2;

import javax.swing.JOptionPane;

public class Exercicio06 {

	public static void main(String[] args) {
		String sexo;
		double altura, peso;
		altura = 0;
		peso = 0;
		JOptionPane.showMessageDialog(null, "Calcular o seu peso ideal.", "Exercício 06", JOptionPane.PLAIN_MESSAGE);
		sexo = JOptionPane.showInputDialog(null, "Qual é o seu sexo? (M, F)", "Sexo", JOptionPane.QUESTION_MESSAGE);
		if (!sexo.equalsIgnoreCase("M") && !sexo.equalsIgnoreCase("F")) {
			JOptionPane.showMessageDialog(null, "Responda apenas com M, para masculino, ou F, para Feminino", "Erro",
					JOptionPane.ERROR_MESSAGE);
		} else {
			altura = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe sua altura em centímetros (cm):", "Altura",
					JOptionPane.QUESTION_MESSAGE));

			if (sexo.equalsIgnoreCase("M")) {
				peso = 52 + (0.75 * (altura - 152.4));
			} else {
				peso = 52 + (0.67 * (altura - 152.4));
			}
			JOptionPane.showMessageDialog(null, String.format("O seu peso ideal é %.2fKg", peso), "Peso ideal",
					JOptionPane.INFORMATION_MESSAGE);

		}
	}

}
