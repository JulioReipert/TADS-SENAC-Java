package Lista2ADO2;

import java.util.Scanner;

public class Exercicio13 {

	public static void main(String[] args) {
		// variáveis
		int ano, resto, proxBi;
		boolean bissexto = false;
		Scanner ler = new Scanner(System.in);
		System.out.println("informe o ano");
		ano = ler.nextInt();
		if (ano % 400 == 0) {
			bissexto = true;
		} else if (ano % 4 == 0 && ano % 100 != 100) {
			bissexto = true;
		}
		resto = ano % 4;
		if (!bissexto) {
			proxBi = ano + 4 - resto;
			if (proxBi % 100 == 0 && proxBi % 400 != 0) {
				proxBi += 4;
			}
			System.out.printf("Não é bissexto. Próximo ano bissexto é %d", proxBi);
		} else {
			System.out.println("Bissexto");
		}

	}

}
