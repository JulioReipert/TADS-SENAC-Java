package Lista2ADO2;

import java.util.Scanner;

public class Exercicio12 {

	public static void main(String[] args) {
		// variáveis
		int hi, mi, hf, mf, dh, dm;
		Scanner ler = new Scanner(System.in);
		// entrada de dados
		System.out.println("informe a hora e os minutos do início:");
		hi = ler.nextInt();
		mi = ler.nextInt();
		System.out.println("informe a hora e os minutos do final:");
		hf = ler.nextInt();
		mf = ler.nextInt();
		dh = hf - hi;
		if (hf < hi) {
			dh += 24;
		}
		dm = mf - mi;
		if (mf < mi) {
			dm += 60;
			dh--;
		}
		System.out.printf("Duração do jogo %2d:%02d", dh, dm);
	}

}
