package Lista2ADO2;

import javax.swing.JOptionPane;

public class Exercicio14 {

	public static void main(String[] args) {
		double nota1, nota2, nota3, media, notaRec, mediaRec;
		JOptionPane.showMessageDialog(null,
				"Aprovação ou reprovação de um aluno por sua média ou média de recuperação.", "Exercício 14",
				JOptionPane.PLAIN_MESSAGE);
		nota1 = Double.parseDouble(
				JOptionPane.showInputDialog(null, "Informe a primeira nota:", "1ª nota", JOptionPane.QUESTION_MESSAGE));
		nota2 = Double.parseDouble(
				JOptionPane.showInputDialog(null, "Informe a segunda nota:", "2ª nota", JOptionPane.QUESTION_MESSAGE));
		nota3 = Double.parseDouble(
				JOptionPane.showInputDialog(null, "Informe a terceira nota:", "3ª nota", JOptionPane.QUESTION_MESSAGE));
		media = (nota1 + nota2 + nota3) / 3;
		if (media >= 6) {
			JOptionPane.showMessageDialog(null, "Aluno aprovado.", "Aprovado", JOptionPane.INFORMATION_MESSAGE);
		} else if (media < 5) {
			JOptionPane.showMessageDialog(null, "Aluno reprovado.", "Reprovado", JOptionPane.ERROR_MESSAGE);
		} else {
			JOptionPane.showMessageDialog(null, "Aluno de recuperação", "Recuperação", JOptionPane.WARNING_MESSAGE);
			notaRec = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe a nota da atividade de recuperação",
					"Nota da recuperação", JOptionPane.QUESTION_MESSAGE));
			mediaRec = (media + notaRec) / 2;
			if (mediaRec < 6) {
				JOptionPane.showMessageDialog(null, "Aluno reprovado.", "Reprovado", JOptionPane.ERROR_MESSAGE);
			} else {
				JOptionPane.showMessageDialog(null, "Aluno aprovado por recuperação.", "Aprovado por recuperação",
						JOptionPane.INFORMATION_MESSAGE);
			}
		}
	}

}
