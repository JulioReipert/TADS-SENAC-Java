package Lista2ADO2;

import javax.swing.JOptionPane;

public class Exercicio11 {

	public static void main(String[] args) {
		double n1, n2, result;
		String opcao;
		opcao = JOptionPane.showInputDialog(null,
				String.format(
						"1. Somar dois números.%n2. Raiz quadrada de um número.%n3. Elevar um número a uma potência."),
				"**** Menu de Opções *****", JOptionPane.QUESTION_MESSAGE);
		if (opcao.equals("1")) {
			n1 = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o primeiro número:",
					"Somar dois números", JOptionPane.QUESTION_MESSAGE));
			n2 = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o segundo número:", "Segundo número",
					JOptionPane.QUESTION_MESSAGE));
			result = n1 + n2;
			JOptionPane.showMessageDialog(null,
					String.format("A soma dos números %.1f e %.1f é igual a %.1f.", n1, n2, result), "Resultado",
					JOptionPane.INFORMATION_MESSAGE);
		} else if (opcao.equals("2")) {
			n1 = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o número:", "Raiz quadrada de um número",
					JOptionPane.QUESTION_MESSAGE));
			result = Math.pow(n1, 0.5);
			JOptionPane.showMessageDialog(null, String.format("A raiz quadrada de %.0f é igual a %.2f.", n1, result),
					"Resultado", JOptionPane.INFORMATION_MESSAGE);
		} else if (opcao.equals("3")) {
			n1 = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o número base:",
					"Elevar um número a uma potência", JOptionPane.QUESTION_MESSAGE));
			n2 = Double.parseDouble(
					JOptionPane.showInputDialog(null, "Informe a potência:", "Potência", JOptionPane.QUESTION_MESSAGE));
			result = Math.pow(n1, n2);
			JOptionPane.showMessageDialog(null,
					String.format("O resultado do número %.1f elevado a potência %.1f é igual a %.1f.", n1, n2, result),
					"Resultado", JOptionPane.INFORMATION_MESSAGE);
		} else {
			JOptionPane.showMessageDialog(null, "Opção incorreta.", "Erro", JOptionPane.ERROR_MESSAGE);
		}
	}

}
