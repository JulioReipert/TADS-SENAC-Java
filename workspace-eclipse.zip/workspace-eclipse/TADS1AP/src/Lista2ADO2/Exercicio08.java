package Lista2ADO2;

import javax.swing.JOptionPane;

public class Exercicio08 {

	public static void main(String[] args) {
		double salarioAtual, novoSalario;
		JOptionPane.showMessageDialog(null, "Calcular novo salário após somado a bonificação e Auxílio Escola.",
				"Exercício 08", JOptionPane.PLAIN_MESSAGE);
		salarioAtual = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o seu salário atual:",
				"Salário atual", JOptionPane.QUESTION_MESSAGE));
		if (salarioAtual > 3000) {
			novoSalario = (salarioAtual + (salarioAtual * 0.05)) + 300;
		} else if (salarioAtual <= 2000) {
			novoSalario = (salarioAtual + (salarioAtual * 0.10)) + 350;
		} else if (salarioAtual > 2000 && salarioAtual <= 2500) {
			novoSalario = (salarioAtual + (salarioAtual * 0.08)) + 350;
		} else {
			novoSalario = (salarioAtual + (salarioAtual * 0.08)) + 300;
		}
		JOptionPane.showMessageDialog(null,
				String.format("Seu novo salário acrescido da bonificação e do Auxílio Escola é R$%.2f.", novoSalario),
				"Novo salário", JOptionPane.INFORMATION_MESSAGE);

	}
}
