package Lista2ADO2;

import javax.swing.JOptionPane;

public class Exercicio09 {

	public static void main(String[] args) {
		double peso, altura, imc;
		String classif;
		JOptionPane.showMessageDialog(null, "Cálculo e classificação de IMC.", "Exercício09",
				JOptionPane.PLAIN_MESSAGE);
		peso = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o seu peso em quilos (Kg):", "Peso",
				JOptionPane.QUESTION_MESSAGE));
		altura = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe sua altura em metros (m):", "Altura",
				JOptionPane.QUESTION_MESSAGE));
		imc = peso / (Math.pow(altura, 2));
		if (imc <= 16) {
			classif = "Magreza Severa";
		} else if (imc > 16 && imc <= 17) {
			classif = "Magreza Moderada";
		} else if (imc > 17 && imc <= 18.5) {
			classif = "Magreza Leve";
		} else if (imc > 18.5 && imc <= 25) {
			classif = "Normal";
		} else if (imc > 25 && imc <= 30) {
			classif = "Obesidade Leve";
		} else if (imc > 30 && imc <= 40) {
			classif = "Obesidade Severa";
		} else {
			classif = "Obesidade Mórbida";
		}
		JOptionPane.showMessageDialog(null, String.format("Sua classificação do IMC é %s.", classif),
				"Classificação IMC", JOptionPane.INFORMATION_MESSAGE);
	}

}