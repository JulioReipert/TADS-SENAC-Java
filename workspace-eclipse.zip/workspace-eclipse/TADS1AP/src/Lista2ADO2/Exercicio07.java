package Lista2ADO2;

import javax.swing.JOptionPane;

public class Exercicio07 {

	public static void main(String[] args) {
		double salario, salarioBrut, grat, salarioLiq, imposto;
		String taxa;
		JOptionPane.showMessageDialog(null, "Calcular o salário líquido.", "Exercício 07", JOptionPane.PLAIN_MESSAGE);
		salario = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o salário base:", "Salário base",
				JOptionPane.QUESTION_MESSAGE));
		grat = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe a gratificação:", "Gratificação recebida",
				JOptionPane.QUESTION_MESSAGE));
		salarioBrut = salario + grat;
		if (salarioBrut < 2500) {
			taxa = "10%";
			imposto = (salarioBrut * 0.10);
			salarioLiq = salarioBrut - imposto;

		} else {
			taxa = "15%";
			imposto = (salarioBrut * 0.15);
			salarioLiq = salarioBrut - imposto;
		}
		JOptionPane
				.showMessageDialog(null,
						"Salário Bruto: R$" + salarioBrut + "; Gratificação: R$" + grat + "; Imposto: R$" + imposto
								+ " (" + taxa + "); Salário líquido: R$" + salarioLiq,
						"Info", JOptionPane.INFORMATION_MESSAGE);
	}
}
