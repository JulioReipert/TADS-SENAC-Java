import java.util.Scanner;

public class CalcularAreaEPerimetro {
	public static void main(String[] args) {
// variáveis
		double base, altura, area, perimetro;
		// variável do tipo Scanner
		Scanner leitor = new Scanner(System.in);
		// mensagem de boas vindas
		System.out.println("Olá!!! Vamos calcular!!");
		System.out.println("Informe a base");
		// receber a base
		base = leitor.nextDouble();
		System.out.println("informe a a altura");
		// receber a altura
		altura = leitor.nextDouble();
		// calcular a area
		area = base * altura;
		// calcular o perimetro
		perimetro = 2 * base + 2 * altura;
		// exibir os valores
		System.out.println("A área é: " + area);
		System.out.println("O perímetro é: " + perimetro);
		leitor.close();

	}
}
