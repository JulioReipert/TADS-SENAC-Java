import java.util.Scanner;

public class Exercicio17 {

	public static void main(String[] args) {
		double cate1, cate2, hipo;
		Scanner ler = new Scanner(System.in);
		System.out.printf(
				"Calculo da hipotenusa de um triângulo a partir dos valores dos catetos.%nInforme o valor do primeiro cateto: ");
		cate1 = ler.nextDouble();
		System.out.printf("Informe o valor do segundo cateto: ");
		cate2 = ler.nextDouble();
		hipo = Math.pow((Math.pow(cate1, 2) + Math.pow(cate2, 2)), 0.5);
		System.out.printf("O valor da hipotenusa é igual a %.2f", hipo);
		ler.close();
	}

}
