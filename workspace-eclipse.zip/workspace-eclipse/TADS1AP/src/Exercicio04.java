import java.util.Scanner;

public class Exercicio04 {
	public static void main(String[] args) {
		double nota1, nota2, nota3, peso1, peso2, peso3, media;
		Scanner ler = new Scanner(System.in);
		System.out.println("Cálculo de média com 3 notas e seus respectivos pesos.");
		System.out.printf("Insira sua primeira nota: ");
		nota1 = ler.nextDouble();
		System.out.printf("Insira o peso da primeira nota: ");
		peso1 = ler.nextDouble();
		System.out.printf("Insira sua segunda nota: ");
		nota2 = ler.nextDouble();
		System.out.printf("Insira o peso da segunda nota: ");
		peso2 = ler.nextDouble();
		System.out.printf("Insira sua terceira nota: ");
		nota3 = ler.nextDouble();
		System.out.printf("Insira o peso da terceira nota: ");
		peso3 = ler.nextDouble();
		media = ((peso1 * nota1) + (peso2 * nota2) + (peso3 * nota3)) / (peso1 + peso2 + peso3);
		System.out.printf("Sua média é %.2f.", media);
		ler.close();

	}

}
