import java.util.Scanner;

public class Exercicio15 {

	public static void main(String[] args) {
		double sacoKg, racaoG, restoG, restoKg;
		Scanner ler = new Scanner(System.in);
		System.out.println(
				"Cálculo da quantidade restante de ração para 2 gatos após 5 dias a partir da quantidade em quilos de um saco de ração e cada gato recebendo a mesma quantidade em gramas por dia.");
		System.out.printf("Insira a quantidade de ração do saco em quilos (Kg): ");
		sacoKg = ler.nextDouble();
		System.out.printf("Insira a quantidade de ração para cada gato em gramas (g): ");
		racaoG = ler.nextDouble();
		restoKg = sacoKg - (((2 * racaoG) / 1000) * 5);
		restoG = (sacoKg * 1000) - ((2 * racaoG) * 5);
		System.out.printf(
				"Quantidade restante de ração após 5 dias em quilos: %.2fKg %nQuantidade restante de ração após 5 dias em gramas: %.2fg",
				restoKg, restoG);
		ler.close();
	}

}
