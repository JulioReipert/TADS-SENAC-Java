package lista1;
import java.util.Scanner;

public class Exercicio12 {

	public static void main(String[] args) {
		double a, b, c, delta, x1, x2;
		Scanner ler = new Scanner(System.in);
		System.out.printf("Cálculo da seguinte equação:%nax² + bx + c = 0%nInsira o valor de a: ");
		a = ler.nextDouble();
		System.out.printf("Insira o valor de b: ");
		b = ler.nextDouble();
		System.out.printf("Insira o valor de c: ");
		c = ler.nextDouble();
		delta = Math.pow(b, 2) - 4 * a * c;
		x1 = (-b + Math.pow(delta, 0.5)) / (2 * a);
		x2 = (-b - Math.pow(delta, 0.5)) / (2 * a);
		System.out.printf("S = {%.2f; %.2f}", x1, x2);
		ler.close();

	}

}
