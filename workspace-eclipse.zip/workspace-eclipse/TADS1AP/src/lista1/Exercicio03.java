package lista1;

import java.util.Scanner;

public class Exercicio03 {

	public static void main(String[] args) {
		// variáveis
		double x1, y1, x2, y2, d;
		Scanner ler = new Scanner(System.in);
		// entrada de dados
		System.out.println("Informe as coordenadas do ponto P1:");
		x1 = ler.nextDouble();
		y1 = ler.nextDouble();
		System.out.println("Informe as coordenadas do ponto P2:");
		x2 = ler.nextDouble();
		y2 = ler.nextDouble();
		// calcular a distância
		d = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
		// exibir
		System.out.printf("A distância é %.0f", d);
		ler.close();

	}

}
