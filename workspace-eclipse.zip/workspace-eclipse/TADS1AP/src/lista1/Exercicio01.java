package lista1;

import java.util.Scanner;

public class Exercicio01 {
	
	public static void main(String[] args) {
		// variáveis
		int ant, num, suc;
		char cAnt, car, cSuc;
		Scanner ler = new Scanner(System.in);
		// entrada de dados
		System.out.println("informe o número: ");
		num = ler.nextInt();
		ant = num - 1;
		suc = num + 1;
		// exibir número, o seu anterior e sucessor
		System.out.printf("%d | %d | %d %n", ant, num, suc);
		// exibir número, o seu anterior e sucessor em uma frase
		System.out.println("O antecessor do número " + num + " é " + ant + " e o sucessor é " + suc + ".");
		// receber o int correspondente ao caractere, guardar numa variável
		System.out.println("\nInforme um número inteiro relativo a um caractere:");
		car = (char) ler.nextInt();
		cAnt = (char) (car - 1);
		cSuc = (char) (car + 1);
		System.out.printf("%c | %c | %c %n", cAnt, car, cSuc);
		System.out.println("O antecessor do caractere " + car + ", segundo a Tabela ASCII, é " + cAnt + " e o sucessor é " + cSuc + ".");
		ler.close();
		
		// forma que eu tinha feito sem a ajuda do professor (utilizei comandos que não fariam falta sem eles e o resultado seria o mesmo):
		/* 
		char charNum, charAnt, charSuc;
		charNum = (char) num;
		charAnt = (char) ant;
		charSuc = (char) suc;
		// exibir caractere, o seu anterior e sucessor
		System.out.printf("%c | %c | %c", charAnt, charNum, charSuc);
		*/
	}

}
