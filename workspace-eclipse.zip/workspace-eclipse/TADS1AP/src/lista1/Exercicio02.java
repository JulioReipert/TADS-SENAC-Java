package lista1;

import java.util.Scanner;

public class Exercicio02 {

	public static void main(String[] args) {
		// variáveis para número de votos
		int total, vBranco, vNulo, vValido;
		// variáveis para porcentagem de votos
		double pBranco, pNulo, pValido;
		Scanner ler = new Scanner(System.in);
		// entrada de dados
		System.out.println("Inserir o total de eleitores:");
		total = ler.nextInt();
		System.out.println("Inserir quantidade de votos válidos:");
		vValido = ler.nextInt();
		System.out.println("Inserir quantidade de votos brancos:");
		vBranco = ler.nextInt();
		System.out.println("Inserir quantidade de votos nulos:");
		vNulo = ler.nextInt();
		// calcular percentuais
		pBranco = 100.0 * vBranco / total;
		pNulo = 100.0 * vNulo / total;
		pValido = 100.0 * vValido / total;
		// Explicação das 3 linhas acima: para obter o resultado em porcentagem, fizemos a multiplicação por 100 e adicionamos a casa decimal par poder trabalhar com casas decimais

		// exibir os resultados
		System.out.printf("%5.2f%% - Válidos%n%5.2f%% - Brancos%n%5.2f%% - Nulos%nTotal: %d", pValido, pBranco, pNulo, total);
		/* Explicação da linha acima: %5.2f - o 5 significa a quantidade de casas a serem utilizadas; o 2f significa o número de casas decimáis; 
		  							     %% - dois síbolos de porcentagem (%) significa que será inserido o simbolo de porcentagem na mensagem escrita, também serve para barra (//) 
		               				     %n - significa pular uma linha; 
		               				     %d - comando para inserir um número decimal.*/
		ler.close();
	}

}
