package lista1;
import java.util.Scanner;

public class Exercicio16 {

	public static void main(String[] args) {
		double pes, polegadas, jardas, milhas;
		Scanner ler = new Scanner(System.in);
		System.out.println("Conversão de medida em pés para polegadas, jardas e milhas.");
		System.out.printf("Insira a medida em pés: ");
		pes = ler.nextDouble();
		polegadas = pes * 12;
		jardas = pes / 3;
		milhas = jardas / 1760;
		System.out.printf("Resultado da conversão de %f em pés para:%n Polegadas: %f%n Jardas: %f%n Milhas: %f", pes,
				polegadas, jardas, milhas);
		ler.close();

	}

}
