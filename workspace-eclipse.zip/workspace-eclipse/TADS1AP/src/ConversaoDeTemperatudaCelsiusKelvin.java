import java.util.Scanner;

public class ConversaoDeTemperatudaCelsiusKelvin {
	public static void main(String[] args) {
		// variáveis
		double tC, tK;
		Scanner ler = new Scanner(System.in);
		// receber temperatura em Celsius
		System.out.println("Calculo de Celsius (°C) para Kelvin (K)");
		System.out.println("Insira a temperatura em Celsius (°C): ");
		tC = ler.nextDouble();
		// converter temperatura em Celsius para Kelvin
		tK = tC + 273.15;
		// informar valores das temperaturas na tela
		System.out.println("A conversão da temperatura em Celsius " + tC + "°C para Kelvin é igual a " + tK + "K.");
		System.out.println(tC + "°C = " + tK + "K");
		ler.close();
	}
}
