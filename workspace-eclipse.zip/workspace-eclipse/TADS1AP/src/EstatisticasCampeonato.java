import java.util.Random;

public class EstatisticasCampeonato {

	public static void main(String[] args) {
		int totalTimes = 5, totalJogadoresPorTime = 15, jogadoresMenoresDe18 = 0, jogadoresMaisDe80Kg = 0;
		double totalAlturas = 0, percentualMaisDe80Kg = 0;

		double[] mediasIdadesTimes = new double[totalTimes];

		Random rand = new Random();

		for (int time = 0; time < totalTimes; time++) {
			double somaIdadesTime = 0;
			double somaAlturasTime = 0;

			for (int jogador = 0; jogador < totalJogadoresPorTime; jogador++) {
				int idadeAleat = rand.nextInt(16) + 16;
				double pesoAleat = 60 + rand.nextDouble() * (91 - 60);
				double alturaAleat = 1.65 + rand.nextDouble() * (1.91 - 1.65);

				System.out.println("Time " + (time + 1) + ", Jogador " + (jogador + 1));
				System.out.println("Idade: " + idadeAleat);
				System.out.printf("Peso (em Kg): %.2f%n", pesoAleat);
				System.out.printf("Altura (em metros): %.2f%n%n", alturaAleat);

				somaIdadesTime += idadeAleat;
				somaAlturasTime += alturaAleat;

				if (idadeAleat < 18) {
					jogadoresMenoresDe18++;
				}

				if (pesoAleat > 80) {
					jogadoresMaisDe80Kg++;
				}
			}

			mediasIdadesTimes[time] = somaIdadesTime / totalJogadoresPorTime;
			totalAlturas += somaAlturasTime;
		}

		for (int time = 0; time < totalTimes; time++) {
			System.out.printf("Média de idade do time %d: %.0f anos.%n", (time + 1), mediasIdadesTimes[time]);
		}

		double mediaAlturas = totalAlturas / (totalTimes * totalJogadoresPorTime);
		percentualMaisDe80Kg = (jogadoresMaisDe80Kg * 100.0) / (totalTimes * totalJogadoresPorTime);

		System.out.printf("Jogadores com idade inferior a 18 anos: %d jogadores.%n", jogadoresMenoresDe18);
		System.out.printf("Média das alturas de todos os jogadores: %.2fm.%n", mediaAlturas);
		System.out.printf("Percentual de jogadores com mais de 80 Kg: %.0f%%.%n", percentualMaisDe80Kg);
	}
}
