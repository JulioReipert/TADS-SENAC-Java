
public class Exercicio11 {

	public static void main(String[] args) {
		double delta, x1, x2;
		System.out.printf("Cálculo da seguinte equação: %nx² - 5x +6 = 0 %n");
		delta = Math.pow(-5, 2) - 4 * 1 * 6;
		x1 = (-(-5) + Math.pow(delta, 0.5)) / (2 * 1);
		x2 = (-(-5) - Math.pow(delta, 0.5)) / (2 * 1);
		System.out.printf("S = {%.0f, %.0f}", x1, x2);
	}

}
