import java.util.Scanner;

public class CalcularMediaAluno {
	public static void main(String[] args) {
		// variáveis
		double n1, n2, n3, n4, media;
		String nome;
		// variável do tipo scanner
		Scanner ler = new Scanner(System.in);
		// mensagem para o Aluno
		System.out.println("Insira seu nome: ");
		// receber o nome
		nome = ler.nextLine();
		System.out.println("Insira suas notas: ");
		// receber notas
		n1 = ler.nextDouble();
		n2 = ler.nextDouble();
		n3 = ler.nextDouble();
		n4 = ler.nextDouble();
		// calcular a soma e depois a divisão
		media = (n1 + n2 + n3 + n4)/4;
		// informar o nome do aluno e sua média
		System.out.println("A média do aluno " + nome + " é igual a " + media);
		ler.close();

	}
}
