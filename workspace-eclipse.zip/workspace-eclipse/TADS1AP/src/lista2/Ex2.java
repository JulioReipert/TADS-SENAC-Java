package lista2;

import javax.swing.JOptionPane;

public class Ex2 {

	public static void main(String[] args) {
		int num1, num2, num3;
		JOptionPane.showMessageDialog(null, "Comparar 3 números e informar o menor.", "Exercício 2",
				JOptionPane.INFORMATION_MESSAGE);
		num1 = Integer.parseInt(
				JOptionPane.showInputDialog(null, "Informe o 1º número:", "Informe", JOptionPane.QUESTION_MESSAGE));
		num2 = Integer.parseInt(
				JOptionPane.showInputDialog(null, "Informe o 2º número:", "Informe", JOptionPane.QUESTION_MESSAGE));
		num3 = Integer.parseInt(
				JOptionPane.showInputDialog(null, "Informe o 3º número:", "Informe", JOptionPane.QUESTION_MESSAGE));
		if (num1 < num2 && num1 < num3) {
			JOptionPane.showMessageDialog(null, "O primeiro número (" + num1 + ") é o menor.");
		} else if (num2 < num1 && num2 < num3) {
			JOptionPane.showMessageDialog(null, "O segundo número (" + num2 + ") é o menor.");
		} else if (num3 < num1 && num3 < num2) {
			JOptionPane.showMessageDialog(null, "O terceiro número (" + num3 + ") é o menor.");
		} else if (num1 == num2 && num1 < num3) {
			JOptionPane.showMessageDialog(null, "O primeiro (" + num1 + ") e o segundo (" + num2
					+ ") número são iguais e são menores que o terceiro (" + num3 + ")");
		} else if (num1 == num3 && num1 < num2) {
			JOptionPane.showMessageDialog(null, "O primeiro (" + num1 + ") e o terceiro (" + num3
					+ ") número são iguais e são menores que o segundo (" + num2 + ")");
		} else if (num2 == num3 && num2 < num1) {
			JOptionPane.showMessageDialog(null, "O segundo (" + num2 + ") e o terceiro (" + num3
					+ ") número são iguais e são menores que o primeiro (" + num1 + ")");
		} else {
			JOptionPane.showMessageDialog(null, "Os números são iguais (" + num1 + ")");
		}
	}

}
