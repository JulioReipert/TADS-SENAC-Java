package lista2;

import javax.swing.JOptionPane;

public class Ex5 {

	public static void main(String[] args) {
		/*
		 * TODO Crie um algoritmo que leia 3 valores e informe se o 3º valor informado
		 * está entre os 2 primeiros.
		 */
		double n1, n2, n3;
		JOptionPane.showMessageDialog(null, "Terceiro valor dentro ou não da faixa entre o primeiro e o segundo",
				"Exercício 5", JOptionPane.PLAIN_MESSAGE);
		n1 = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o primeiro valor", "1º valor",
				JOptionPane.QUESTION_MESSAGE));
		n2 = Double.parseDouble(
				JOptionPane.showInputDialog(null, "Informe o segundo valor", "2º valor", JOptionPane.QUESTION_MESSAGE));
		n3 = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o terceiro valor", "3º valor",
				JOptionPane.QUESTION_MESSAGE));
		if (n3 >= n1 && n3 <= n2) {
			JOptionPane.showMessageDialog(null, "O número " + n3 + " está dentro da faixa de " + n1 + " e " + n2);
		} else if (n3 >= n2 && n3 <= n1) {
			JOptionPane.showMessageDialog(null, "O número " + n3 + " está dentro da faixa de " + n1 + " e " + n2);
		} else {
			JOptionPane.showMessageDialog(null, "O número " + n3 + " não está dentro da faixa de " + n1 + " e " + n2);
		}
	}

}
