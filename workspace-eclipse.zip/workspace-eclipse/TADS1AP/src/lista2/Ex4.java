package lista2;

import javax.swing.JOptionPane;

public class Ex4 {

	public static void main(String[] args) {
		double num;
		JOptionPane.showMessageDialog(null, "Faixa de 1 a 100", "Exercício 4", JOptionPane.PLAIN_MESSAGE);
		num = Double.parseDouble(JOptionPane.showInputDialog("informe o número", JOptionPane.QUESTION_MESSAGE));
		if (num >= 1 && num <= 100) {
			JOptionPane.showMessageDialog(null, "O número " + num + " está dentro da faixa de 1 a 100.",
					"Está na faixa", JOptionPane.INFORMATION_MESSAGE);
		} else {
			JOptionPane.showMessageDialog(null, "O número " + num + " não está dentro da faixa de 1 a 100.",
					"Não está na faixa", JOptionPane.ERROR_MESSAGE);
		}

	}

}
