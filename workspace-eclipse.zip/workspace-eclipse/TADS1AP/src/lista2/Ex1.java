package lista2;

import javax.swing.JOptionPane;

public class Ex1 {

	public static void main(String[] args) {
		int num1, num2;
		JOptionPane.showMessageDialog(null, "Bem-vindo", "Comparar 2 números", JOptionPane.INFORMATION_MESSAGE);
		num1 = Integer.parseInt(
				JOptionPane.showInputDialog(null, "Informe o 1º número:", "Informe", JOptionPane.QUESTION_MESSAGE));
		num2 = Integer.parseInt(
				JOptionPane.showInputDialog(null, "Informe o 2º número:", "Informe", JOptionPane.QUESTION_MESSAGE));
		if (num1 > num2) {
			JOptionPane.showMessageDialog(null, "O primeiro número: " + num1 + " é o maior");
		} else if (num2 > num1) {
			JOptionPane.showMessageDialog(null, "O segundo número: " + num2 + " é o maior");
		} else {
			JOptionPane.showMessageDialog(null, "Os números são iguais");
		}

	}

}
