package lista2;

import javax.swing.JOptionPane;

public class Ex3 {

	public static void main(String[] args) {
		int n1, n2, n3, n4, media;
		String nome, classif;
		JOptionPane.showMessageDialog(null, "Notas, média e classificação do aluno", "Exercício 3",
				JOptionPane.INFORMATION_MESSAGE);
		nome = JOptionPane.showInputDialog(null, "Informe o nome do aluno", "Aluno", JOptionPane.QUESTION_MESSAGE);
		n1 = Integer.parseInt(
				JOptionPane.showInputDialog(null, "Informe a primeira nota", "Nota 1", JOptionPane.QUESTION_MESSAGE));
		n2 = Integer.parseInt(
				JOptionPane.showInputDialog(null, "Informe a primeira nota", "Nota 1", JOptionPane.QUESTION_MESSAGE));
		n3 = Integer.parseInt(
				JOptionPane.showInputDialog(null, "Informe a terceira nota", "Nota 3", JOptionPane.QUESTION_MESSAGE));
		n4 = Integer.parseInt(
				JOptionPane.showInputDialog(null, "Informe a quarta nota", "Nota 4", JOptionPane.QUESTION_MESSAGE));
		media = (n1 + n2 + n3 + n4) / 4;
		if (media <= 20) {
			classif = "Péssimo";
		} else if (media <= 40) {
			classif = "Ruim";
		} else if (media <= 60) {
			classif = "Regular";
		} else if (media <= 80) {
			classif = "Bom";
		} else {
			classif = "Ótimo";
		}
		JOptionPane.showMessageDialog(null, "O aluno " + nome + " tirou as notas " + n1 + ", " + n2 + ", " + n3 + ", "
				+ n4 + " e obteve uma média igual a " + media + ". Sua classificação é: " + classif);
	}
}
