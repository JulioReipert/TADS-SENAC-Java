import java.util.Scanner;

public class Exercicio09 {

	public static void main(String[] args) {
		double raio, area, perimetro;
		Scanner ler = new Scanner(System.in);
		System.out.println("Cálculo de área e perímetro de um círculo a partir do seu raio.");
		System.out.println("Informe o raio do círculo:");
		raio = ler.nextDouble();
		area = Math.PI * Math.pow(raio, 2);
		perimetro = 2 * Math.PI * raio;
		System.out.printf("A área do círculo é %f e seu perímetro é %f.", area, perimetro);
		ler.close();

	}

}
