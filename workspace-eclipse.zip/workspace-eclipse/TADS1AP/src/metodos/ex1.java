package metodos;

import java.util.Scanner;

public class ex1 {

	public static void main(String[] args) {
		Scanner leia = new Scanner(System.in);
		double x, y, soma;
		System.out.println("Informe 2 números");
		x = leia.nextDouble();
		y = leia.nextDouble();
		soma = somar(x, y);
	}

	/**
	 * Este método soma dois valores e retorna o resultado
	 * 
	 * @param n1 primeiro valor a ser somado
	 * @param n2 segundo valor a ser somado
	 * @return soma dos dois valores
	 */
	public static double somar(double n1, double n2) {
		double resultado;
		resultado = n1 + n2;
		return resultado;
	}

	/**
	 * Este método soma dois valores e retorna o resultado
	 * 
	 * @param n1 primeiro valor a ser somado
	 * @param n2 segundo valor a ser somado
	 * @return soma dos dois valores
	 */
	public static double somar(double n1, double n2, double n3) {
		double resultado;
		resultado = n1 + n2 + n3;
		return resultado;
	}

	// criar um método para calcular a área de um triângulo
	public static double areaTriangulo(double b, double h) {
		double area;
		area = (b * h) / 2;
		return area;
	}

	// criar um método para verificar se um número é múltiplo de outro
	public static boolean multiplo(int n1, int n2) {
		return n1 % n2 == 0;
	}

}
