package repeticao;

public class ExemploFor {

	public static void main(String[] args) {
		int num = 5;
		printTabuada(num, 45);
	}

	// tabuada usando for
	public static void printTabuada(int n) {
		for (int i = 1; i <= 10; i++) {
			System.out.printf("%02d x %02d = %03d%n", n, i, n * i);
		}
	}

	public static void printTabuada(int n, int limite) {
		for (int i = 1; i <= limite; i++) {
			System.out.printf("%02d x %02d = %03d%n", n, i, n * i);
		}
	}
}
