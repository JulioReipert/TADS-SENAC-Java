package repeticao;

import java.util.Scanner;

public class ExemploBreak {

	public static void main(String[] args) {
		Scanner leia = new Scanner(System.in);
		int numero;
		do {
			System.out.println("Informe um número");
			numero = leia.nextInt();
			if (numero < 1 || numero > 10) {
				System.out.println("Número inválido");
				continue;
			}
			break;
		} while (true);

	}

}
