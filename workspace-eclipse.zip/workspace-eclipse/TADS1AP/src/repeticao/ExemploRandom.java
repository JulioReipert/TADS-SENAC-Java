package repeticao;

import java.util.Random;

public class ExemploRandom {

	public static void main(String[] args) {
		int n1, n2, n3, media;
		Random rand = new Random();
		int aleat1 = rand.nextInt(98,100);
		int aleat2 = rand.nextInt(100);
		System.out.println(aleat1);
		System.out.println(aleat2);

		for (int i = 1; i <= 50; i++) {
			media = 0;
			for (int j = 1; j <= 3; j++) {
				System.out.printf("informe a nota %d do aluno %d%n", j, i);
				media = media + rand.nextInt(101);
			}
			media = media / 3;
			System.out.printf("Média: %d%n", media);
		}
	}

}
