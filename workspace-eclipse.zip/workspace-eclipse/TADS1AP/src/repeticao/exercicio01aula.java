package repeticao;

import java.util.Scanner;

public class exercicio01aula {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		int ni, nf;
		System.out.println("digite o número inicial e o número final:");
		ni = ler.nextInt();
		nf = ler.nextInt();
		divisor2e3(ni, nf);
	}

	public static void divisor2e3(int ni, int nf) {
		for (int i = ni; i <= nf; i++) {
			if (i % 2 == 0 && i % 3 == 0) {
				System.out.printf("número entre %d e %d divisível por 2 e 3 ao mesmo tempo: %d%n", ni, nf, i);
			}

		}
	}

}
