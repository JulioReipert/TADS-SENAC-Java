package repeticao;

import java.util.Random;
import java.util.Scanner;

public class ExemploWhile {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		Random rand = new Random();
		int numero, cont = 0;
		System.out.println("informe um número entre 1 e 10");
		numero = ler.nextInt();
		while (numero < 1 || numero > 10) {
			System.out.println("Número inválido. Digite outro");
			numero = rand.nextInt();
			cont++;
		}
		System.out.println(cont);
		tabuadaWhile(numero);

	}

	public static void tabuadaWhile(int num) {
		int mult = 1;
		while (mult <= 10) {
			System.out.printf("%2d x %2d = %2d%n", num, mult, num * mult);
			mult++;
		}
	}

}
