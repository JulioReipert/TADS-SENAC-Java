package repeticao;

import java.util.Random;

public class ExemploDo {

	public static void main(String[] args) {
		Random rand = new Random();
		int numero;
		do {
			System.out.println("Informe um número entre 1 e 10");
			numero = rand.nextInt(100);
		} while (numero < 1 || numero > 10);
		tabuadaDoWhile(numero);

	}

	public static void tabuadaDoWhile(int num) {
		int mult = 1;
		do {
			System.out.printf("%2d x %2d = %2d%n", num, mult, num * mult);
			mult++;
		} while (mult <= 10);
		
	}
}
