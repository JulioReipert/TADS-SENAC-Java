package exercíciosSwitchCase;

import java.util.Scanner;

public class ex1 {

	public static void main(String[] args) {
		String plano;
		double valor;
		Scanner ler = new Scanner(System.in);
		System.out.println("informe o plano");
		plano = ler.nextLine();
		//switch (plano.equalsIgnoreCase()) {
		
		}
	}

//}
