package exercíciosSwitchCase;

import java.util.Scanner;

public class ex3 {

	public static void main(String[] args) {
		int codigo;
		double salario, aumento, novoSalario;
		Scanner ler = new Scanner(System.in);
		System.out.println("informe o código correspondente ao cargo");
		codigo = ler.nextInt();
		System.out.println("informe o salário");
		salario = ler.nextDouble();
		switch (codigo) {
		case 1 -> {
			aumento = (salario * 0.5);
			novoSalario = salario + aumento;
			System.out.printf("Seu cargo é Escriturário. Você recebeu um aumento de R$%.2f. Seu novo salário é R$%.2f",
					aumento, novoSalario);
		}
		case 2 -> {
			aumento = (salario * 0.35);
			novoSalario = salario + aumento;
			System.out.printf("Seu cargo é Secretário. Você recebeu um aumento de R$%.2f. Seu novo salário é R$%.2f",
					aumento, novoSalario);
		}
		case 3 -> {
			aumento = (salario * 0.2);
			novoSalario = salario + aumento;
			System.out.printf("Seu cargo é Caixa. Você recebeu um aumento de R$%.2f. Seu novo salário é R$%.2f",
					aumento, novoSalario);
		}
		case 4 -> {
			aumento = (salario * 0.1);
			novoSalario = salario + aumento;
			System.out.printf("Seu cargo é Gerente. Você recebeu um aumento de R$%.2f. Seu novo salário é R$%.2f",
					aumento, novoSalario);
		}
		case 5 -> {
			aumento = (salario * 0);
			novoSalario = salario + aumento;
			System.out.printf("Seu cargo é Diretor. Você recebeu um aumento de R$%.2f. Seu novo salário é R$%.2f",
					aumento, novoSalario);
		}
		}
	}
}