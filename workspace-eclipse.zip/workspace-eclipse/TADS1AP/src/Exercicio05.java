import java.util.Scanner;

public class Exercicio05 {

	public static void main(String[] args) {
		String nome;
		double sAntigo, aumento, sNovo;
		Scanner ler = new Scanner(System.in);
		System.out.println("Cálculo de salário somado a um aumento de 25%.");
		System.out.println("Digite o nome do funcionário:");
		nome = ler.nextLine();
		System.out.println("digite o valor do salário:");
		sAntigo = ler.nextDouble();
		aumento = sAntigo * 0.25;
		sNovo = sAntigo + aumento;
		System.out.printf("O funcionário %s ganhou um aumento de %.2f e passou a receber um salário de %.2f. ", nome,
				aumento, sNovo);
		ler.close();
	}

}
