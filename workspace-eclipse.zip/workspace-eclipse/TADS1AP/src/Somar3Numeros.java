import java.util.Scanner;

public class Somar3Numeros {
	public static void main(String[] args) {
		// criar variáveis
		double n1, n2, n3, soma;
		// variável do tipo Scanner
		Scanner leitor = new Scanner(System.in);
		// informar primeiro número
		System.out.println("Calcular soma de 3 números");
		System.out.println("informe o primeiro número");
		// receber primeiro número
		n1 = leitor.nextDouble();
		System.out.println("informe o segundo número");
		// receber segundo número
		n2 = leitor.nextDouble();
		System.out.println("informe o terceiro número");
		// receber terceiro número
		n3 = leitor.nextDouble();
		// calcular a soma dos três números
		soma = n1 + n2 + n3;
		// exibir o valor
		System.out.println("A soma dos números " + n1 + ", " + n2 + " e " + n3 + " é igual a " + soma);
		leitor.close();

	}
}
