package array;

import java.util.Random;
import java.util.Scanner;

public class ExemploArray2 {
	// Algoritmo para receber o nome e 3 notas de 4 alunos
	// ao final exiba o nome, as notas e as mÃ©dias dos alunos
	public static void main(String[] args) {
		Scanner leia = new Scanner(System.in);
		Random rand = new Random();
		String[] nomes = new String[4];
		// array bidimensional de 4 x 4
		double[][] notas = new double[4][4];
		for (int i = 0; i < nomes.length; i++) {
			System.out.println("Informe o nome do aluno " + (i + 1));
			nomes[i] = leia.next();
			double media = 0;
			for (int j = 0; j < 3; j++) {
				System.out.printf("Informe a nota %d do aluno %d%n", (j + 1), (i + 1));
				notas[i][j] = rand.nextDouble(10);
				media += notas[i][j];
			}
			media = media / 3;
			notas[i][3] = media;
		}
		// exibindo as notas
		System.out.printf("%-10s|%6s|%6s|%6s|%6s%n", "Nome", "Nota 1", "Nota 2", "Nota 3", "Média");
		for (int i = 0; i < nomes.length; i++) {
			System.out.printf("%-10s", nomes[i]);
			for (int j = 0; j < 4; j++) {
				System.out.printf("|%6.2f", notas[i][j]);
			}
			System.out.println();
		}

	}
}