import java.util.Scanner;

public class Exercicio08 {

	public static void main(String[] args) {
		double area, base, altura;
		Scanner ler = new Scanner(System.in);
		System.out.println("Cálculo da área de um triângulo a partir de sua base e altura.");
		System.out.println("Digite o valor da base do triângulo:");
		base = ler.nextDouble();
		System.out.println("Digite o valor da altura do triângulo:");
		altura = ler.nextDouble();
		area = (base * altura) / 2;
		System.out.printf("A área do triângulo é igual a %f.", area);
		ler.close();
	}

}
